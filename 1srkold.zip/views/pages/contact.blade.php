
      <nav class="breadcrumb" style="padding-left:15px;margin-bottom:5px;">
          <ul xmlns:v="http://rdf.data-vocabulary.org/#">
              <li class="breadhome" typeof="v:Breadcrumb">
                  <a href="{{ home_url() }}" property="v:title" rel="v:url">
                      <span property="name">Home</span>
                  </a>
              </li> 
              <li>{{ ucwords(str_replace('-', ' ', $page)) }}</li>
          </ul>
      </nav>

<div style="padding: 0px 30px 0px 30px">
		
<h1>Contact</h1>
				<p align="justify">Have any question, comment, suggestion or news tip to pass along to www.eluxurysall.com?</p>
	<p align="justify">We are open to discuss all of the possibilities with you. This page offering the right way to sent any comments to&nbsp;www.eluxurysall.com admin related to your feedback, news coverage and other issues related to this site.</p>
	<p>We are happy to hear information from you please write a subject format:</p>
	<ul style="padding: 0px 10px 0px 30px ">
	<li><strong>Claim Picture</strong>&nbsp;[picture name] [url to real picture] : if you are the real owner to claim your picture and need back links.</li>
	<li><strong>Submit Wallpapers</strong>&nbsp;[wallpaper name] : if you wanna submit your or your wallpaper design to us.</li>
	<li><strong>Advertise</strong>&nbsp;: if you interested to advertising on our site.</li>
	<li><strong>Support</strong> : if you need our support.</li>
	</ul>
	<p>And send all your inquiries to our official mail at richardhcarsons@gmail.com</p>
	<p align="justify">Don’t hesitate to contact us according your concerns and don’t worry, all of your comment are welcome. :) </p>
	<p align="justify">Thank you.</p>

</div>
